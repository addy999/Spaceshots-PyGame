# Gravity Assists
---


### Note: SI Units used throughout library
```
- Time: s (seconds)
- Distance: m (meters)
- Mass: kg (kilograms)
```
